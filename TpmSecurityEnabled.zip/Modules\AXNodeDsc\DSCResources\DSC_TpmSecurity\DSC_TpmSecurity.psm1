$modulePath = Join-Path -Path (Split-Path -Path (Split-Path -Path $PSScriptRoot -Parent) -Parent) -ChildPath 'Modules'

# Import the AXNodeDsc Common Module
Import-Module -Name (Join-Path -Path $modulePath `
        -ChildPath (Join-Path -Path 'AXNodeDsc.Common' `
            -ChildPath 'AXNodeDsc.Common.psm1'))

function Get-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateSet('TpmSecurity')]
        [String]
        $AttributeName,

        [Parameter(Mandatory = $true)]
        [ValidateSet('On','Off')]
        [String]
        $AttributeValue
    )

    $curAttributeValue = Get-AXNodeBiosAttribute -AttributeName $AttributeName

    $configuration = @{
        AttributeName = $AttributeName
        AttributeValue = $AttributeValue
    }

    if ($curAttributeValue -ne $attributeValue)
    {
        $configuration.Add('Status', $false)
        $code = 'TpmSecurity:TpmSecurity:AttributeValueNotValid'
        $phrase = "$AttributeName is not set to the desired value '$AttributeValue'."
    }
    else
    {
        $configuration.Add('Status', $true)
        $code = 'TpmSecurity:TpmSecurity:AttributeValueValid'
        $phrase = "$AttributeName is set to the desired value '$AttributeValue'."
    }

    $reasons = @()
    $reasons += @{
        Code = $code
        Phrase = $phrase
    }

    $configuration.Add('Reasons', $reasons)

    return $configuration
}

function Set-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateSet('TpmSecurity')]
        [String]
        $AttributeName,

        [Parameter(Mandatory = $true)]
        [ValidateSet('On','Off')]
        [String]
        $AttributeValue
    )

    #Do nothing
}

function Test-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateSet('TpmSecurity')]
        [String]
        $AttributeName,

        [Parameter(Mandatory = $true)]
        [ValidateSet('On','Off')]
        [String]
        $AttributeValue
    )

    $attributeValueCurrent = Get-AXNodeBiosAttribute -AttributeName $AttributeName
    $message =("Desired Attribute Value: {0} and Current Attribute Value: {1}" -f $AttributeValue, $attributeValueCurrent)

    if ($attributeValue -eq $attributeValueCurrent)
    {
        Write-Verbose -Message "[NoAction] $message"
        return $true
    }
    else
    {
        Write-Verbose -Message "[Update needed] $message"
        return $false
    }
}

Export-ModuleMember -Function *-TargetResource