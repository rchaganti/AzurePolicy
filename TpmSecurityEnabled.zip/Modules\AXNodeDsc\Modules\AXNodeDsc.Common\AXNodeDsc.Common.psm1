if ($PSVersionTable.PSEdition -ne 'Core')
{
    Add-Type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
    ServicePoint srvPoint, X509Certificate certificate,
    WebRequest request, int certificateProblem) {
        return true;
    }
}
"@

    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

    $allProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
    [System.Net.ServicePointManager]::SecurityProtocol = $allProtocols
}

$baseUri = 'https://idrac.local/redfish/v1'

function Get-AXNodeBIOSAttribute
{
    [CmdletBinding()]
    param 
    (
        [Parameter()]
        [pscredential]
        $BMCCredential,

        [Parameter(Mandatory = $true)]
        [string]
        $AttributeName
    )

    if (!$BMCCredential)
    {
        $dracPassword = ConvertTo-SecureString -String 'calvin' -AsPlainText -Force
        $BMCCredential = New-Object -TypeName PSCredential -ArgumentList 'root', $dracPassword
    }

    $biosAttrUri = "${baseUri}/Systems/System.Embedded.1/Bios"
    $requestParams = @{
        UseBasicParsing = $true
        Uri = $biosAttrUri
        Headers = @{
            Accept = '*/*'
        }
        Credential = $BMCCredential
    }

    if ($PSVersionTable.PSEdition -eq 'Core')
    {
        $requestParams.Add('SkipCertificateCheck', $true)
    }

    $biosAttributes = (Invoke-RestMethod @requestParams).Attributes

    if ($biosAttributes.PSObject.Properties.Name -contains $AttributeName)
    {
        return $biosAttributes.$AttributeName
    }
    else
    {
        throw "An attribute with name $AttributeName does not exist"    
    }
}
